public class LetterPrinter {
	public static void main(String[] args) {
		System.out.println("XXXX");
		System.out.println("X");
		System.out.println("XXXX");
		System.out.println("   X");
		System.out.println("XXXX");
	}
}
